<?php
include "dbconnection.php";
$count = 0;
?>
<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8"> <!-- set character type -->
    <meta name="viewport" content="width=device-width, initial-scale=1" /> <!-- scaling for mobile devices -->
    <link rel=stylesheet href="style.css" /> <!-- style.css added -->
    <link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'> <!-- Quicksand font has added -->
    <title> Odev 3 </title> <!-- title has set -->
</head>

<body>
    <center>
        <div class="box">
        <a href="index.php">
            <div id="selection1"> Yeni kayıt</div>
        </a>
        <a href="records.php">
            <div id="selection2">kayıtlar </div>
        </a>
        </div>
    </center>